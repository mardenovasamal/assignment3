public class Node<K, V> {
    public K key;
    public V value;
    // Rest of the code...
}
