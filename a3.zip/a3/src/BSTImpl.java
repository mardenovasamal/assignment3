import java.util.function.Consumer;

public class BSTImpl<K extends Comparable<K>, V> extends bst<K, V> implements BSTImpl1 {
    @Override
    public void forEach(Consumer<? super Node<K, V>> action) {
        super.forEach((Consumer<? super Node<K, V>>) action);
    }
}
