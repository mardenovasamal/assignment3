import java.util.Iterator;

public class BST<K extends Comparable<K>, V> implements Iterable<bst.Node<K, V>> {
    private Node<K, V> root;
    private int size;

    public class Node<K, V> {
        private K key;
        private V value;
        private Node<K, V> left, right;

        public Node(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }
    }

    public void put(K key, V value) {
        // Implementation for adding nodes
    }

    public V get(K key) {
        // Implementation for getting nodes
        return null;
    }

    public void delete(K key) {
        // Implementation for deleting nodes
    }

    public int size() {
        return size;
    }

    public Iterator<bst.Node> iterator() {
        // Implementation for in-order traversal iterator
        return new InorderIterator(root);
    }

    // Other helper methods...

    public static void main(String[] args) {
        // Test code...
    }
}